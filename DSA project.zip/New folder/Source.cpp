#include <iostream>
#include <string>
using namespace std;

const int MAX_BOOKINGS = 1000;

struct Train {
    int trainId;
    string trainName;
    string source;
    string destination;
    string departureTime;
    string arrivalTime;
    int totalSeats;
    int availableSeats;
    float fare;
    Train* left;
    Train* right;

    Train() : trainId(0), totalSeats(0), availableSeats(0), fare(0.0f), left(NULL), right(NULL) {}
};

struct Passenger {
    int passengerId;
    string name;
    int age;
    string contact;
    string gender;
    Passenger() : passengerId(0), age(0) {}
};

struct Booking {
    int bookingId;
    int trainId;
    int passengerId;
    int seatNumber;
    string bookingDate;
    string journeyDate;
    string status;
    float amountPaid;
    Booking() : bookingId(0), trainId(0), passengerId(0), seatNumber(0), amountPaid(0.0f), status("NONE") {}
};

struct BookingNode {
    Booking data;
    BookingNode* next;
    BookingNode(const Booking& b) : data(b), next(NULL) {}
};

class BookingList {
private:
    BookingNode* head;
    int size;
public:
    BookingList() : head(NULL), size(0) {}

    ~BookingList() {
        clear();
    }

    void insert(const Booking& b) {
        BookingNode* node = new BookingNode(b);
        if (!head)
            head = node;
        else {
            BookingNode* temp = head;
            while (temp->next)
                temp = temp->next;
            temp->next = node;
        }
        size++;
    }

    Booking* find(int bookingId) {
        BookingNode* cur = head;
        while (cur) {
            if (cur->data.bookingId == bookingId)
                return &cur->data;
            cur = cur->next;
        }
        return NULL;
    }

    BookingNode* getHead() {
        return head;
    }
    int getSize() const {
        return size;
    }
    void clear() {
        while (head) {
            BookingNode* t = head;
            head = head->next;
            delete t;
        }
        size = 0;
    }
};

class TrainBST {
private:
    Train* root;
    int size;
    Train* insertNode(Train* node, const Train& newTrain) {
        if (!node) {
            Train* node = new Train(newTrain);
            return node;
        }
        if (newTrain.trainId < node->trainId)
            node->left = insertNode(node->left, newTrain);
        else if (newTrain.trainId > node->trainId)
            node->right = insertNode(node->right, newTrain);
        return node;
    }

    Train* searchNode(Train* node, int id) {
        if (!node)
            return NULL;
        if (id == node->trainId)
            return node;
        if (id < node->trainId)
            return searchNode(node->left, id);
        return searchNode(node->right, id);
    }

    void inorder(Train* node) {
        if (!node)
            return;
        inorder(node->left);
        int booked = node->totalSeats - node->availableSeats;
        cout << "Train ID: " << node->trainId << ", Name: " << node->trainName
            << ", Route: " << node->source << " -> " << node->destination
            << ", Seats (Booked/Total): " << booked << "/" << node->totalSeats
            << ", Available: " << node->availableSeats << ", Fare: " << node->fare << endl;
        inorder(node->right);
    }

    void clearNode(Train* node) {
        if (!node)
            return;
        clearNode(node->left);
        clearNode(node->right);
        delete node;
    }

    void searchByRoute(Train* node, const string& src, const string& dest, bool& found) {
        if (!node)
            return;
        searchByRoute(node->left, src, dest, found);
        if (node->source == src && node->destination == dest) {
            cout << "Train " << node->trainName << " (ID: " << node->trainId << ") "
                << "Seats: " << node->availableSeats << "/" << node->totalSeats << endl;
            found = true;
        }
        searchByRoute(node->right, src, dest, found);
    }
public:
    TrainBST() : root(NULL), size(0) {}

    ~TrainBST() {
        clearNode(root);
    }
    void insert(const Train& train) {
        root = insertNode(root, train);
        size++;
    }

    Train* find(int id) {
        return searchNode(root, id);
    }

    void displayAll() {
        inorder(root);
    }

    int getSize() const {
        return size;
    }

    void searchByRoute(const string& src, const string& dest, bool& found) {
        searchByRoute(root, src, dest, found);
    }
};

class TrainReservationSystem {
private:
    TrainBST trains;
    Passenger* passengers[MAX_BOOKINGS];
    int passengerCount;
    BookingList bookings;
    int nextTrainId;
    int nextPassengerId;
    int nextBookingId;

    Passenger* findPassenger(int id) {
        for (int i = 0; i < passengerCount; i++) {
            if (passengers[i]->passengerId == id)
                return passengers[i];
        }
        return NULL;
    }
public:
    TrainReservationSystem() : passengerCount(0), nextTrainId(1), nextPassengerId(1), nextBookingId(1) {}

    void addTrain() {
        Train t;
        t.trainId = nextTrainId++;
        cout << "Assigned Train ID: " << t.trainId << endl;
        cout << "Enter Train Name: ";
        getline(cin, t.trainName);


        bool nameExists = false;
        for (int i = 1; i < nextTrainId; i++) {
            Train* existingTrain = trains.find(i);
            if (existingTrain != NULL && existingTrain->trainName == t.trainName) {
                nameExists = true;
                break;
            }
        }

        if (nameExists) {
            cout << "Train with this name already exists! Invalid" << endl;
            return;
        }

        while (true) {
            cout << "Enter Source: ";
            getline(cin, t.source);
            cout << "Enter Destination: ";
            getline(cin, t.destination);
            if (t.source == t.destination) {
                cout << "Source and destination cannot be the same! Try again." << endl;
                continue;
            }
            break;
        }
        cout << "Enter Departure Time (HH:MM): ";
        getline(cin, t.departureTime);
        cout << "Enter Arrival Time (HH:MM): ";
        getline(cin, t.arrivalTime);
        while (true) {
            cout << "Enter Total Seats: ";
            cin >> t.totalSeats;
            cin.ignore();
            if (t.totalSeats <= 0) {
                cout << "Seats must be more than 0! Try again." << endl;
                continue;
            }
            break;
        }
        while (true) {
            cout << "Enter Fare: ";
            cin >> t.fare;
            cin.ignore();
            if (t.fare <= 0) {
                cout << "Fare must be greater than 0! Try again." << endl;
                continue;
            }
            break;
        }
        t.availableSeats = t.totalSeats;
        trains.insert(t);
        cout << "Train added successfully!" << endl;
    }



    void displayAllTrains() {
        trains.displayAll();
    }

    void addPassenger() {
        Passenger* p = new Passenger();
        p->passengerId = nextPassengerId++;
        cout << "Enter name: ";
        getline(cin, p->name);
        cout << "Enter age: ";
        cin >> p->age;
        cin.ignore();
        cout << "Enter contact: ";
        getline(cin, p->contact);
        cout << "Enter gender: ";
        getline(cin, p->gender);

        passengers[passengerCount++] = p;

        cout << "Passenger added! ID: " << p->passengerId << endl;
    }

    Train* findTrain(int id) {
        return trains.find(id);
    }

    void bookTicket() {
        int trainId, passengerId;
        cout << "Enter Train ID: ";
        cin >> trainId;
        cout << "Enter Passenger ID: ";
        cin >> passengerId;
        cin.ignore();
        Train* t = findTrain(trainId);
        Passenger* p = findPassenger(passengerId);
        if (!t || !p) {
            cout << "Invalid IDs!\n";
            return;
        }

        Booking b;
        b.trainId = trainId;
        b.passengerId = passengerId;
        b.amountPaid = t->fare;
        cout << "Enter journey date (DD/MM/YYYY): ";
        getline(cin, b.journeyDate);
        b.bookingDate = "10/09/2025";
        if (t->availableSeats > 0) {
            b.bookingId = nextBookingId++;
            b.status = "CONFIRMED";
            b.seatNumber = t->totalSeats - t->availableSeats + 1;
            t->availableSeats--;
            bookings.insert(b);
            cout << "Booking CONFIRMED! ID: " << b.bookingId << " Seat: " << b.seatNumber << endl;
        }
        else {
            cout << "Train full. Booking REJECTED." << endl;
            return;
        }
    }

    void cancelBooking() {
        int id;
        cout << "Enter Booking ID: ";
        cin >> id;
        cin.ignore();
        Booking* b = bookings.find(id);
        if (!b || b->status == "CANCELLED") {
            cout << "Invalid booking!" << endl;
            return;
        }
        Train* t = findTrain(b->trainId);
        if (b->status == "CONFIRMED" && t) {
            t->availableSeats++;
            cout << "Seat freed for Train " << t->trainName << endl;
        }
        b->status = "CANCELLED";
        cout << "Booking cancelled." << endl;
    }

    void searchTrains() {
        string src, dest;
        cout << "Enter source: ";
        getline(cin, src);
        cout << "Enter destination: ";
        getline(cin, dest);
        cout << "=== SEARCH RESULTS ===" << endl;
        bool found = false;
        trains.searchByRoute(src, dest, found);
        if (!found)
            cout << "No train found for route " << src << " -> " << dest << endl;
    }

    void viewBookingHistory() {
        int pid;
        cout << "Enter Passenger ID: ";
        cin >> pid;
        cin.ignore();
        Passenger* p = findPassenger(pid);
        if (!p) {
            cout << "No passenger found with ID " << pid << endl;
            return;
        }
        BookingNode* cur = bookings.getHead();

        cout << "=== Booking History for Passenger " << pid << " ===" << endl;
        bool any = false;
        while (cur) {
            if (cur->data.passengerId == pid) {
                any = true;
                cout << "Booking " << cur->data.bookingId << " Train " << cur->data.trainId
                    << " Status: " << cur->data.status << " Seat: " << cur->data.seatNumber << endl;
            }
            cur = cur->next;
        }
        if (!any)
            cout << "No bookings found for passenger " << pid << endl;
    }

    void generateReport() {
        cout << "Trains: " << trains.getSize() << ", Passengers: " << passengerCount
            << ", Bookings: " << bookings.getSize() << endl;
    }

    void run() {
        while (true) {
            cout << "=== MENU ===" << endl;
            cout << "1.Add Train" << endl;
            cout << "2.Display Trains" << endl;
            cout << "3.Add Passenger" << endl;
            cout << "4.Book Ticket" << endl;
            cout << "5.Cancel Booking" << endl;
            cout << "6.Search Trains" << endl;
            cout << "7.View Booking History" << endl;
            cout << "8.Report" << endl;
            cout << "0.Exit" << endl;
            cout << "Choice: " << endl;
            int ch;
            cin >> ch;
            cin.ignore();
            switch (ch) {
            case 1: addTrain();
                break;
            case 2: displayAllTrains();
                break;
            case 3: addPassenger();
                break;
            case 4: bookTicket();
                break;
            case 5: cancelBooking();
                break;
            case 6: searchTrains();
                break;
            case 7: viewBookingHistory();
                break;
            case 8: generateReport();
                break;
            case 0:
                return;
            default:
                cout << "Invalid choice!" << endl;
            }
        }
    }
};

int main() {
    TrainReservationSystem sys;
    sys.run();
    return 0;
}